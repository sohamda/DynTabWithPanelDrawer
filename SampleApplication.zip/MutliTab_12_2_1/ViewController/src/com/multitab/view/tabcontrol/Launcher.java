package com.multitab.view.tabcontrol;

import javax.faces.event.ActionEvent;

import oracle.ui.pattern.dynamicShell.TabContext;

public class Launcher {
    
    public Launcher() {
        super();
    }
    
    public void launchDepartments(ActionEvent actionEvent) {
      launchActivity("Departments", "/WEB-INF/department-flow-definition.xml#department-flow-definition", false);
    }
    
    public void launchJobs(ActionEvent actionEvent) {
      launchActivity("Jobs", "/jobs-flow-definition.xml#jobs-flow-definition", false);
    }
    
    private void launchActivity(String title, String taskflowId, boolean newTab) {
        try { 
            if (newTab) {
                TabContext.getCurrentInstance().addTab(
                title,
                taskflowId);
            } else {
                TabContext.getCurrentInstance().addOrSelectTab(
                title,
                taskflowId);
            }
        } catch (TabContext.TabOverflowException toe) {
            // causes a dialog to be displayed to the user saying that there are
            // too many tabs open - the new tab will not be opened...
            toe.handleDefault(); 
        }
    }
}
